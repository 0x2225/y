﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _KitapDukkani
{
    class Musteri
    {
        public string ad { get; set; }
        public string meslek { get; set; }
        public Kitap kitap { get; set; }
        public int yas { get; set; }
    }
}
