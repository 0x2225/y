﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _KitapDukkani
{
    class Kitap
    {
        public string kitapAdi { get; set; }
        public string kitapTuru { get; set; }
        public int sayfaSayisi { get; set; }
        public decimal fiyat { get; set; }
        public Yazar yazar { get; set; }
        
    }
}
