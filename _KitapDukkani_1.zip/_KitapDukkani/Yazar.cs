﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _KitapDukkani
{
    class Yazar
    {
        public string ad { get; set; }
        public DateTime dogumTarihi { get; set; }
        public bool nobel { get; set; }
    }
}
