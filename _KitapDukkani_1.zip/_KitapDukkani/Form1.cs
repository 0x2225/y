﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _KitapDukkani
{
    public partial class Form1 : Form
    {
        List<Musteri> musteriler = new List<Musteri>() { };
        List<Kitap> kitaplar = new List<Kitap>() { };
        List<Yazar> yazarlar = new List<Yazar>() { };
        public Form1()
        {
            InitializeComponent();
            cmbYazar.DisplayMember = "ad";
            cmbKitap.DisplayMember = "kitapAdi";
        }

        private void btnYazarEkle_Click(object sender, EventArgs e)
        {
            Yazar yazar = new Yazar() { ad = this.txtYazarAdi.Text, dogumTarihi = this.dtYazarDogumTarihi.Value, nobel = this.chkNobel.Checked};
            yazarlar.Add(yazar);
            this.cmbYazar.Items.Add(yazar);
        }

        private void btnKitapEkle_Click(object sender, EventArgs e)
        {
            Kitap kitap = new Kitap() { kitapAdi = this.txtKitapAdi.Text, yazar = (Yazar)this.cmbYazar.SelectedItem, sayfaSayisi = int.Parse(this.txtSayfaSayisi.Text), fiyat = decimal.Parse(this.txtFiyat.Text), kitapTuru = (string)this.cmbKitapTuru.Text };
            kitaplar.Add(kitap);
            this.cmbKitap.Items.Add(kitap);
        }

        private void btnMusteriEkle_Click(object sender, EventArgs e)
        {
            Musteri musteri = new Musteri() { ad = this.txtMusteriAdi.Text, kitap = (Kitap)this.cmbKitap.SelectedItem, meslek = this.txtMeslegi.Text, yas = int.Parse(this.txtMusteriYas.Text)};
            musteriler.Add(musteri);
        }

        private string Multiply(string str, int multiplier)
        {
            string o = "";
            for (int i = 0; i < multiplier; i++)
            {
                o += str;
            }
            return o;
        }
        private void btnMusterileriGetir_Click(object sender, EventArgs e)
        {
            this.lsbMusteriler.Items.Clear();
            foreach (Musteri musteri in musteriler)
            {
                this.lsbMusteriler.Items.Add(musteri.ad+"       "+musteri.yas+"         "+musteri.meslek+"       "+musteri.kitap.kitapAdi);
            }
        }



       
        
    }
}
